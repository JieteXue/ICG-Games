"""
Dawson-Kayles Game Package
"""

from .game import DawsonKaylesGame

__all__ = ['DawsonKaylesGame']